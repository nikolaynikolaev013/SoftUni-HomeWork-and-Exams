﻿using System;
namespace EasterRaces.Utilities
{
    public enum CarTypes
    {
        Muscle = 1,
        Sports = 2
    }
}
