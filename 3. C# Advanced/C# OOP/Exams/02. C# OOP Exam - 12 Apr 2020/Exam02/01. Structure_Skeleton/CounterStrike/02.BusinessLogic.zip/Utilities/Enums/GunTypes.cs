﻿using System;
namespace CounterStrike.Utilities.Enums
{
    public enum GunTypes
    {
        Pistol = 1,
        Rifle = 2
    }
}
