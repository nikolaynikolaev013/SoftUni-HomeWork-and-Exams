﻿using System;
namespace CounterStrike.Utilities.Enums
{
    public enum PlayerTypes
    {
        Terrorist = 1,
        CounterTerrorist = 2
    }
}
