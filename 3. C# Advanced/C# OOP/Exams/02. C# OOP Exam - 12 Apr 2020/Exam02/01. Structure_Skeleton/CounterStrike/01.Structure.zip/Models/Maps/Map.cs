﻿using System;
using System.Collections.Generic;
using System.Linq;
using CounterStrike.Models.Maps.Contracts;
using CounterStrike.Models.Players;
using CounterStrike.Models.Players.Contracts;
using CounterStrike.Utilities.Enums;
using CounterStrike.Utilities.Messages;

namespace CounterStrike.Models.Maps
{
    public class Map : IMap
    {
        public Map()
        {
        }

        public string Start(ICollection<IPlayer> players)
        {
            ICollection<IPlayer> terrorists = players.Where(x => x.GetType().Name.ToString() == PlayerTypes.Terrorist.ToString()).ToList();
            ICollection<IPlayer> counterTerrorists = players.Where(x => x.GetType().Name.ToString() == PlayerTypes.CounterTerrorist.ToString()).ToList();

            while (terrorists.Count > 0 && counterTerrorists.Count > 0)
            {
                foreach (var terrorist in terrorists)
                {
                    foreach (var counterTerrorist in counterTerrorists)
                    {
                        counterTerrorist.TakeDamage(terrorist.Gun.Fire());

                        if (!counterTerrorist.IsAlive)
                        {
                            counterTerrorists.Remove(counterTerrorist);
                        }
                    }
                }
                foreach (var counterTerrorist in counterTerrorists)
                {
                    foreach (var terrorist in terrorists)
                    {
                        terrorist.TakeDamage(counterTerrorist.Gun.Fire());
                        if (!terrorist.IsAlive)
                        {
                            terrorists.Remove(terrorist);
                        }
                    }
                }
            }

            return terrorists.Count > 0 ? OutputMessages.TerroristsWon : OutputMessages.CounterTerroristsWon;
        }
    }
}
