﻿using System;
namespace RobotService.Utilities.Enums
{
    public enum RobotTypes
    {
        HouseholdRobot = 1,
        PetRobot = 2,
        WalkerRobot = 3
    }
}
