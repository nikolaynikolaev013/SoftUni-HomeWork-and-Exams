﻿using System;
namespace RobotService.Utilities.Enums
{
    public enum ProcedureTypes
    {
        Charge = 1,
        Chip = 2,
        Polish = 3,
        Rest = 4,
        TechCheck = 5,
        Work = 6
    }
}
