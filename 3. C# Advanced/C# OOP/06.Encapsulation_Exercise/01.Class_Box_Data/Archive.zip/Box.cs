﻿using System;
namespace _01.Class_Box_Data
{
    public class Box
    {
        private double length;
        private double width;
        private double height;
        public Box(double length, double width, double height)
        {
            this.Length = length;
            this.Width = width;
            this.Height = height;
        }

        private double Length {
            get
            {
                return this.length;
            }
            set
            {
                var temp = 0.0;
                if (!double.TryParse(value.ToString(), out temp) || temp < 1)
                {
                    throw new ArgumentException("Length cannot be zero or negative.");
                }
                length = temp;
            }
        }
        private double Width {
            get
            {
                return this.width;
            }
            set
            {
                var temp = 0.0;
                if (!double.TryParse(value.ToString(), out temp) || temp < 1)
                {
                    throw new ArgumentException("Width cannot be zero or negative.");
                }
                width = temp;
            }
        }
        private double Height {
            get {
                return this.height;
            }
            set {
                var temp = 0.0;
                if (!double.TryParse(value.ToString(), out temp) || temp < 1)
                {
                    throw new ArgumentException("Height cannot be zero or negative.");
                }
                height = temp;
            }
        }


        public double SurfaceArea()
        {
            return 2 * (Width * Length + Height * Length + Height * Width);
        }

        public double LateralSurfaceArea()
        {
            return 2 * Length * Height + 2 * Width * Height;
        }

        public double Volume()
        {
            return Length * Width * Height;
        }
    }
}
