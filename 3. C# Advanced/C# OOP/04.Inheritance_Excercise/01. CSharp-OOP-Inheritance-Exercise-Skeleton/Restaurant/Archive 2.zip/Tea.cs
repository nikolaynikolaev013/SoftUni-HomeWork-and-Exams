﻿using System;
namespace Restaurant
{
    public class Tea : HotBeverage
    {
        public Tea(string name, decimal price, double ml) : base(name, price, ml)
        {
        }
    }
}
