﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using ValidationAttributes.Attributes;

namespace ValidationAttributes
{
    public static class Validator
    {
        public static bool IsValid(object obj)
        {
            Type type = obj.GetType();

            PropertyInfo[] attributes = type.GetProperties();

            foreach (var attribute in attributes)
            {
                List<MyValidationAttribute> myAttributes = attribute.GetCustomAttributes<MyValidationAttribute>().ToList();

                object propObj = attribute.GetValue(obj);

                foreach (var MyValidationAttribute in myAttributes)
                {
                    bool res = MyValidationAttribute.isValid(propObj);

                    if (!res)
                    {
                        return false;
                    }
                }
            }
            return true;
        }
    }
}
