﻿using System;
namespace _04.Border_Control
{
    public interface IPerson
    {
        string Name { get; }
        int Age { get; }
    }
}
