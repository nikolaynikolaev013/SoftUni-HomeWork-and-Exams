﻿using System;
namespace _04.Border_Control
{
    public interface INamable
    {
        string Name { get; }
    }
}
