﻿using System;
namespace _04.Border_Control
{
    public interface IIdentifiable
    {
        string Id { get; }

    }
}
