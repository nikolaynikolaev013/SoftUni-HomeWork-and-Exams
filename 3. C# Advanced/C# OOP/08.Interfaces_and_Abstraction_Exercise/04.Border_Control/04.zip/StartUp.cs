﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _04.Border_Control
{
    class StartUp
    {
        static void Main(string[] args)
        {
            var input = String.Empty;

            var checkedIds = new List<IIdentifiable>();

            while ((input = Console.ReadLine()) != "End")
            {
                var command = input.Split(" ", StringSplitOptions.RemoveEmptyEntries).ToArray();

                if (command.Length == 3)
                {
                    checkedIds.Add(new Citizen(command[0], int.Parse(command[1]), command[2]));
                }
                else
                {
                    checkedIds.Add(new Robot(command[0], command[1]));
                }
            }

            var fakeIdSuffix = Console.ReadLine();

            Console.WriteLine(String.Join(Environment.NewLine, checkedIds.Where(x => x.Id.EndsWith(fakeIdSuffix)).Select(x=>x.Id)));
        }
    }
}
