﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _04.Border_Control
{
    class StartUp
    {
        static void Main(string[] args)
        {
            var input = String.Empty;

            var checkedIds = new List<IBirthable>();

            while ((input = Console.ReadLine()) != "End")
            {
                var command = input.Split(" ", StringSplitOptions.RemoveEmptyEntries).ToArray();

                switch (command[0])
                {
                    case "Pet":
                        checkedIds.Add(new Pet(command[1], command[2]));
                        break;
                    case "Citizen":
                        checkedIds.Add(new Citizen(command[1], int.Parse(command[2]), command[3], command[4]));
                        break;
                    default:
                        continue;
                        break;
                }
            }

            var fakeYear = Console.ReadLine();

            Console.WriteLine(String.Join(Environment.NewLine, checkedIds.Where(x => x.Birthdate.EndsWith(fakeYear)).Select(x=>x.Birthdate)));
        }
    }
}
