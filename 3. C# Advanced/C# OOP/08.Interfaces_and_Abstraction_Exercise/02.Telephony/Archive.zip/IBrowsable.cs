﻿using System;
namespace _02.Telephony
{
    public interface IBrowsable
    {
        string Browse(string website);
    }
}
