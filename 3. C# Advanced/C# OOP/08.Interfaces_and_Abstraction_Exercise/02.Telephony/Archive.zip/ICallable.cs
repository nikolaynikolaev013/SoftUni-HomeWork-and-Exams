﻿using System;
namespace _02.Telephony
{
    public interface ICallable
    {
        string Call(string number);
    }
}
