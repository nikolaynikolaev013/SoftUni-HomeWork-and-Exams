﻿using System;
namespace _04.Wild_Farm.IO
{
    public class Reader : IReader
    {

        public string ReadLine()
        {
            return Console.ReadLine();
        }
    }
}
