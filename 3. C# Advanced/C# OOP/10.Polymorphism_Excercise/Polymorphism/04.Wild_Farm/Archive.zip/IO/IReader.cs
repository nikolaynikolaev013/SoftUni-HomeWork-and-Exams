﻿using System;
namespace _04.Wild_Farm.IO
{
    public interface IReader
    {
        string ReadLine();
    }
}
