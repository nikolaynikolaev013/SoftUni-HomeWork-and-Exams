﻿using System;
namespace _04.Wild_Farm.Core
{
    public interface IEngine
    {
        void Run();
    }
}
