﻿using System;
namespace _04.Wild_Farm.Models.Animals.Birds
{
    public interface IBird
    {
        double WingSize { get; }
    }
}
