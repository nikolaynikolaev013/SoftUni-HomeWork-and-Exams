﻿using System;
namespace _04.Wild_Farm.Models.Animals.Mammals.Felines
{
    public interface IFeline
    {
        string Breed { get; }
    }
}
