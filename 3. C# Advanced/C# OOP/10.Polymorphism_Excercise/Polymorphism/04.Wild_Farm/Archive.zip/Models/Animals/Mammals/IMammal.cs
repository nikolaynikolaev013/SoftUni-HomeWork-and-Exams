﻿using System;
namespace _04.Wild_Farm.Models.Animals
{
    public interface IMammal
    {
        string LivingRegion { get; }
    }
}
