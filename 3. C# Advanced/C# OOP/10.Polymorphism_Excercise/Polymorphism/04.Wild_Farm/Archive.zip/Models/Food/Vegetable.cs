﻿using System;
namespace _04.Wild_Farm.Models
{
    public class Vegetable : Food
    {
        public Vegetable(int quantity) : base(quantity)
        {
        }
    }
}
