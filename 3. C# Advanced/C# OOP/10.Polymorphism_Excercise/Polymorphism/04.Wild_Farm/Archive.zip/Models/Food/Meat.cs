﻿using System;
namespace _04.Wild_Farm.Models
{
    public class Meat : Food
    {
        public Meat(int quantity) : base(quantity)
        {
        }
    }
}
