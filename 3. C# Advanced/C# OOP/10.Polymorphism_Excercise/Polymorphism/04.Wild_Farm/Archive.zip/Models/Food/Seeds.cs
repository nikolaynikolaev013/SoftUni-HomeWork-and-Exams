﻿using System;
namespace _04.Wild_Farm.Models
{
    public class Seeds : Food
    {
        public Seeds(int quantity) : base(quantity)
        {
        }
    }
}
