﻿using System;
namespace _04.Wild_Farm.Utilities
{
    public static class Exceptions
    {
        public const string InvalidFoodException = "{0} does not eat {1}!";
    }
}
