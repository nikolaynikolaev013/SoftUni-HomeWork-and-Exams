﻿using System;
namespace _01.Vehicles.Models
{
    public class Truck : Vehicle
    {
        private const double acConsumption = 1.6;
        private const double DefaultFuelCapacityPercentage = 0.95;

        public Truck(double fuelQuantity, double fuelConsumption, bool isACOn = true) : base(fuelQuantity, fuelConsumption, isACOn)
        {
        }

        public override double ACConsumption => acConsumption;

        public override void Refuel(double liters)
        {
            base.Refuel(liters * DefaultFuelCapacityPercentage);
        }
    }
}
