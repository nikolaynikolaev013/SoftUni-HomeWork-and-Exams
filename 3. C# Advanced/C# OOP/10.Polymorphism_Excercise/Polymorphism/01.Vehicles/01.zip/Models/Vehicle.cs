﻿using System;
namespace _01.Vehicles.Models
{
    public abstract class Vehicle : IVehicle
    {
        public Vehicle(double fuelQuantity, double fuelConsumption, bool isACOn = true)
        {
            this.FuelQuantity = fuelQuantity;
            this.FuelConsumption = fuelConsumption;
            this.IsACOn = isACOn;
        }
        public double FuelQuantity { get; private set; }

        public double FuelConsumption { get; private set; }

        public bool IsACOn { get; private set; }

        public abstract double ACConsumption { get; }

        public bool Drive(double distance)
        {
            var usedFuel = distance * FuelConsumption;

            if (IsACOn)
            {
                usedFuel += distance * ACConsumption;
            }

            if (usedFuel <= FuelQuantity)
            {
                FuelQuantity -= usedFuel;
                return true;
            }

            return false;
        }

        public virtual void Refuel(double liters)
        {
            FuelQuantity += liters;
        }

        public override string ToString()
        {
            return $"{this.GetType().Name}: {this.FuelQuantity:F2}";
        }
    }
}
