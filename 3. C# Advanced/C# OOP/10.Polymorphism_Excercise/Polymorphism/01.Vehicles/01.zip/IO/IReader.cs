﻿using System;
namespace _01.Vehicles.IO
{
    public interface IReader
    {
        string CustomReader();
    }
}
