﻿using System;
namespace _01.Vehicles.IO
{
    public interface IWriter
    {
        void CustomWriter(string text);
    }
}
