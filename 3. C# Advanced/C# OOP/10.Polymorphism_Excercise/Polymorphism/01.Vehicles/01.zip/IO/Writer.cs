﻿using System;
namespace _01.Vehicles.IO
{
    public class Writer : IWriter
    {

        public void CustomWriter(string text)
        {
            Console.WriteLine(text);
        }
    }
}
