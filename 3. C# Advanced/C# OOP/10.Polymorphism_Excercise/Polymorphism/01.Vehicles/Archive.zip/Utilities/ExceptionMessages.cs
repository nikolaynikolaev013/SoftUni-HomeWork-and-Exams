﻿using System;
namespace _01.Vehicles.Utilities
{
    public static class ExceptionMessages
    {
        public const string InvalidFuelAmount = "Cannot fit {0} fuel in the tank";
        public const string NegativeFuelAmount = "Fuel must be a positive number";
    }
}
