﻿using System;
namespace _03.Raiding.IO
{
    public class Reader : IReader
    {

        public string Read()
        {
            return Console.ReadLine();
        }
    }
}
