﻿using System;
namespace _03.Raiding.IO
{
    public interface IReader
    {
        string Read();
    }
}
