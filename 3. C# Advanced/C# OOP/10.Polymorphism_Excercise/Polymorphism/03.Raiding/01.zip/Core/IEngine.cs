﻿using System;
using _03.Raiding.Factories;
using _03.Raiding.IO;

namespace _03.Raiding.Core
{
    public interface IEngine
    {
        void Run();
    }
}
