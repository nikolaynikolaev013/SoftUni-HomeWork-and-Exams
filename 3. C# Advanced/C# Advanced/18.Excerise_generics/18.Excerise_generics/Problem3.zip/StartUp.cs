﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _18.Excerise_generics
{
    class StartUp
    {
        static void Main(string[] args)
        {
            var n = int.Parse(Console.ReadLine());
            List<Box<string>> list = new List<Box<string>>();

            for (int i = 0; i < n; i++)
            {
                var box = new Box<string>(Console.ReadLine());
                list.Add(box);
            }

            int[] indexes = Console.ReadLine()
                .Split(" ", StringSplitOptions.RemoveEmptyEntries)
                .Select(int.Parse)
                .ToArray();

            list = Box<string>.Swap(list, indexes[0], indexes[1]);

            Console.WriteLine(String.Join(Environment.NewLine, list));
        }
    }
}
