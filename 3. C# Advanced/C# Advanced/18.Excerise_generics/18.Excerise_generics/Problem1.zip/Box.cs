﻿using System;
using System.Text;

namespace _18.Excerise_generics
{
    public class Box<T>
    {
        public T Value { get; set; }

        public Box()
        {
        }

        public Box(T value)
        {
            this.Value = value;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append(Value.GetType());
            sb.Append(": ");
            sb.Append(Value);
            return sb.ToString();
        }
    }
}
