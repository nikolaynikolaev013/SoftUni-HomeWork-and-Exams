﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _18.Excerise_generics
{
    class StartUp
    {
        static void Main(string[] args)
        {
            var n = int.Parse(Console.ReadLine());
            var list = new List<Box<int>>();

            for (int i = 0; i < n; i++)
            {
                var box = new Box<int>(int.Parse(Console.ReadLine()));
                list.Add(box);
            }

            int[] indexes = Console.ReadLine()
                .Split(" ", StringSplitOptions.RemoveEmptyEntries)
                .Select(int.Parse)
                .ToArray();

            list = Box<int>.Swap(list, indexes[0], indexes[1]);

            Console.WriteLine(String.Join(Environment.NewLine, list));
        }
    }
}
