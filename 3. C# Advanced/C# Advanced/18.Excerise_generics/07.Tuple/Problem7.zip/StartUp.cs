﻿using System;
using System.Linq;

namespace _07.Tuple
{
    class StartUp
    {
        static void Main(string[] args)
        {
            string[] command = Console.ReadLine()
                .Split(" ", StringSplitOptions.RemoveEmptyEntries)
                .ToArray();

            var name = command[0] + " " + command[1];

            var tuple1 = new Tuple<string, string>(name, command[2]);
            Console.WriteLine(tuple1.ToString());

            command = Console.ReadLine()
                .Split(" ", StringSplitOptions.RemoveEmptyEntries)
                .ToArray();

            var tuple2 = new Tuple<string, int>(command[0], int.Parse(command[1]));
            Console.WriteLine(tuple2.ToString());

            command = Console.ReadLine()
                .Split(" ", StringSplitOptions.RemoveEmptyEntries)
                .ToArray();
            var tuple3 = new Tuple<int, double>(int.Parse(command[0]), double.Parse(command[1]));

            Console.WriteLine(tuple3.ToString());
        }
    }
}
