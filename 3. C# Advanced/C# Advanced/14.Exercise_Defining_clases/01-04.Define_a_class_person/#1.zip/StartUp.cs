﻿using System;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Person p1 = new Person();
            p1.Name = "Pesho";
            p1.Age = 20;

            Person p2 = new Person("Gosho", 18);

            Person p3 = new Person("Stamat", 43);
        }
    }
}
