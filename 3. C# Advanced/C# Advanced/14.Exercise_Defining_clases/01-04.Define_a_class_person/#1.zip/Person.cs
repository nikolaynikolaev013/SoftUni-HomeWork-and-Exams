﻿using System;

namespace DefiningClasses
{
    public class Person
    {
        private string name;
        private byte age;


        public string Name { get { return this.name; } set { this.name = value; } }
        public byte Age { get { return this.age; } set { this.age = value; } }

        public Person()
        {

        }
        public Person(string name, byte age)
        {
            Name = name;
            Age = age;
        }
    }
}
