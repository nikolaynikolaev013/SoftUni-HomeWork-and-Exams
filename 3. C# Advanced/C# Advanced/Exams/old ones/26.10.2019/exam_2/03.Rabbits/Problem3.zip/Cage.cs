﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Rabbits
{
    public class Cage
    {
        List<Rabbit> data;

        public Cage()
        {
        }
        public Cage(string name, int capacity)
        {
            this.Name = name;
            this.Capacity = capacity;
            this.Data = new List<Rabbit>();
        }

        public string Name { get; set; }
        public int Capacity { get; set; }
        public List<Rabbit> Data {
            get
            {
                return this.data;
            }
            set {
                this.data = value;
            }
        }
        public int Count { get { return this.data.Count; } }

        public void Add(Rabbit rabbit)
        {
            if (data.Count + 1 < Capacity)
            {
                data.Add(rabbit);
            }
        }

        public bool RemoveRabbit(string name)
        {
            if (data.Any(x=>x.Name == name))
            {
                data.RemoveAll(x=>x.Name == name);
                return true;
            }
            return false;
        }

        public void RemoveSpecies(string species)
        {
            data.RemoveAll(x => x.Species == species);
        }

        public Rabbit SellRabbit(string name)
        {
            if (data.Any(x=>x.Name == name))
            {
                data.First(x => x.Name == name).Available = false;
                return data.First(x => x.Name == name);
            }
            return null;
        }

        public Rabbit[] SellRabbitsBySpecies(string species)
        {
            if (data.Any(x=>x.Species == species))
            {
                Rabbit[] newArray = data.Where(x => x.Species == species).Select(x =>
                { x.Available = false;
                    return x;
                }
                ).ToArray();

                return newArray;
            }

            return null;
        }


        public string Report()
        {
            StringBuilder str = new StringBuilder();

            str.AppendLine($"Rabbits available at {this.Name}");
            str.AppendLine(String.Join(Environment.NewLine, data.Where(x=>x.Available == true)));

            return str.ToString().Trim();
        }
    }
}
