﻿namespace Heroes
{
    internal class SringBuilder
    {
        public SringBuilder()
        {
        }
    }
}